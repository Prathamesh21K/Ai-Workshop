package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.BookmarkAdded
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.SalesTrackUiState
import com.example.ui.components.formatConversion
import com.example.ui.theme.StatusBookedColor
import com.example.ui.theme.StatusSoldColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
  uiState: SalesTrackUiState,
  onManageLeads: () -> Unit,
  onViewReports: () -> Unit,
  onBackToWelcome: () -> Unit,
) {
  BackHandler { onBackToWelcome() }

  Scaffold(
    containerColor = MaterialTheme.colorScheme.background,
    contentWindowInsets = WindowInsets.safeDrawing,
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = stringResource(R.string.dashboard_greeting, uiState.salesExecutiveName),
              style = MaterialTheme.typography.titleLarge,
            )
            Text(
              text = stringResource(R.string.dashboard_subtitle),
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        },
        actions = {
          IconButton(
            onClick = onBackToWelcome,
            modifier = Modifier.testTag("switch_executive_button"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ExitToApp,
              contentDescription = stringResource(R.string.switch_executive),
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        },
        colors =
          TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
          ),
      )
    },
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .widthIn(max = 600.dp)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
      ) {
        // 2x2 KPI Summary Cards
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            MetricCard(
              title = stringResource(R.string.metric_total_leads),
              value = uiState.totalLeads.toString(),
              icon = Icons.Filled.People,
              accentColor = MaterialTheme.colorScheme.onBackground,
              modifier = Modifier.weight(1f).testTag("metric_total_leads"),
            )
            MetricCard(
              title = stringResource(R.string.metric_bookings),
              value = uiState.bookingsCount.toString(),
              icon = Icons.Filled.BookmarkAdded,
              accentColor = StatusBookedColor,
              modifier = Modifier.weight(1f).testTag("metric_bookings"),
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            MetricCard(
              title = stringResource(R.string.metric_completed_sales),
              value = uiState.completedSalesCount.toString(),
              icon = Icons.Filled.CheckCircle,
              accentColor = StatusSoldColor,
              modifier = Modifier.weight(1f).testTag("metric_completed_sales"),
            )
            MetricCard(
              title = stringResource(R.string.metric_conversion),
              value = formatConversion(uiState.conversionPercentage),
              icon = Icons.Filled.TrendingUp,
              accentColor = MaterialTheme.colorScheme.primary,
              modifier = Modifier.weight(1f).testTag("metric_conversion"),
            )
          }
        }

        // Quick Actions Section
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text(
            text = stringResource(R.string.quick_actions_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
          )

          Button(
            onClick = onManageLeads,
            modifier = Modifier.fillMaxWidth().height(54.dp).testTag("manage_leads_button"),
            shape = RoundedCornerShape(12.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
              ),
          ) {
            Icon(
              imageVector = Icons.Filled.People,
              contentDescription = null,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = stringResource(R.string.manage_leads_button),
              style = MaterialTheme.typography.labelLarge,
            )
          }

          OutlinedButton(
            onClick = onViewReports,
            modifier = Modifier.fillMaxWidth().height(54.dp).testTag("view_reports_button"),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            colors =
              ButtonDefaults.outlinedButtonColors(
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
              ),
          ) {
            Icon(
              imageVector = Icons.Filled.Assessment,
              contentDescription = null,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = stringResource(R.string.view_reports_button),
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun MetricCard(
  title: String,
  value: String,
  icon: ImageVector,
  accentColor: Color,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = title,
        tint = accentColor,
        modifier = Modifier.size(22.dp),
      )
      Text(
        text = value,
        style = MaterialTheme.typography.headlineLarge,
        color = accentColor,
      )
      Text(
        text = title,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

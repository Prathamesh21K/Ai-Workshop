package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.LeadStatus
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.StatusBookedColor
import com.example.ui.theme.StatusContactedColor
import com.example.ui.theme.StatusLostColor
import com.example.ui.theme.StatusNewColor
import com.example.ui.theme.StatusSoldColor
import com.example.ui.theme.StatusTestRideColor
import java.util.Locale

fun LeadStatus.accentColor(): Color =
  when (this) {
    LeadStatus.NEW -> StatusNewColor
    LeadStatus.CONTACTED -> StatusContactedColor
    LeadStatus.TEST_RIDE -> StatusTestRideColor
    LeadStatus.BOOKED -> StatusBookedColor
    LeadStatus.SOLD -> StatusSoldColor
    LeadStatus.LOST -> StatusLostColor
  }

fun formatConversion(percentage: Float): String =
  String.format(Locale.US, "%.1f%%", percentage)

@Composable
fun StatusBadge(
  status: LeadStatus,
  modifier: Modifier = Modifier,
  showDropdownIcon: Boolean = false,
  onClick: (() -> Unit)? = null,
) {
  val accent = status.accentColor()
  val content: @Composable () -> Unit = {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Text(
        text = status.label,
        style = MaterialTheme.typography.labelMedium,
        color = accent,
      )
      if (showDropdownIcon) {
        Icon(
          imageVector = Icons.Filled.ArrowDropDown,
          contentDescription = null,
          tint = accent,
          modifier = Modifier.size(18.dp),
        )
      }
    }
  }

  if (onClick != null) {
    Surface(
      onClick = onClick,
      modifier = modifier.minimumInteractiveComponentSize(),
      shape = RoundedCornerShape(8.dp),
      color = CharcoalElevated,
      border = BorderStroke(1.dp, accent.copy(alpha = 0.55f)),
      content = content,
    )
  } else {
    Surface(
      modifier = modifier,
      shape = RoundedCornerShape(8.dp),
      color = CharcoalElevated,
      border = BorderStroke(1.dp, accent.copy(alpha = 0.55f)),
      content = content,
    )
  }
}

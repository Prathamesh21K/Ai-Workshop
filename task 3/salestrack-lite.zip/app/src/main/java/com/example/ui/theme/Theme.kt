package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SalesTrackColorScheme =
  darkColorScheme(
    primary = SubtleRed,
    onPrimary = CrispWhite,
    primaryContainer = SubtleRedContainer,
    onPrimaryContainer = SubtleRedOnContainer,
    secondary = CrispWhite,
    onSecondary = ObsidianBlack,
    secondaryContainer = CharcoalElevated,
    onSecondaryContainer = CrispWhite,
    background = ObsidianBlack,
    onBackground = CrispWhite,
    surface = CharcoalSurface,
    onSurface = CrispWhite,
    surfaceVariant = CharcoalElevated,
    onSurfaceVariant = MutedSteel,
    outline = CharcoalBorder,
    outlineVariant = CharcoalBorder,
    error = StatusLostColor,
    onError = ObsidianBlack,
  )

@Composable
fun SalesTrackTheme(content: @Composable () -> Unit) {
  MaterialTheme(colorScheme = SalesTrackColorScheme, typography = Typography, content = content)
}

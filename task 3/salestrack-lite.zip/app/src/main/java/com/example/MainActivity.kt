package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AppScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.LeadManagementScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.SalesTrackTheme
import com.example.viewmodel.SalesTrackViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
    )
    setContent {
      SalesTrackTheme {
        SalesTrackApp()
      }
    }
  }
}

@Composable
fun SalesTrackApp(salesTrackViewModel: SalesTrackViewModel = viewModel()) {
  val uiState by salesTrackViewModel.uiState.collectAsStateWithLifecycle()

  when (uiState.currentScreen) {
    AppScreen.WELCOME -> {
      WelcomeScreen(
        initialName = uiState.salesExecutiveName,
        onContinue = { name -> salesTrackViewModel.continueToDashboard(name) },
      )
    }
    AppScreen.DASHBOARD -> {
      DashboardScreen(
        uiState = uiState,
        onManageLeads = { salesTrackViewModel.navigateTo(AppScreen.LEADS) },
        onViewReports = { salesTrackViewModel.navigateTo(AppScreen.REPORTS) },
        onBackToWelcome = { salesTrackViewModel.navigateTo(AppScreen.WELCOME) },
      )
    }
    AppScreen.LEADS -> {
      LeadManagementScreen(
        leads = uiState.leads,
        onAddLead = { name, phone, model, status ->
          salesTrackViewModel.addLead(name, phone, model, status)
        },
        onUpdateLeadStatus = { leadId, newStatus ->
          salesTrackViewModel.updateLeadStatus(leadId, newStatus)
        },
        onBack = { salesTrackViewModel.navigateTo(AppScreen.DASHBOARD) },
      )
    }
    AppScreen.REPORTS -> {
      ReportsScreen(
        uiState = uiState,
        onBack = { salesTrackViewModel.navigateTo(AppScreen.DASHBOARD) },
      )
    }
  }
}

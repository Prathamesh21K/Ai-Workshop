package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PersonOutline
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.Lead
import com.example.model.LeadStatus
import com.example.model.SuggestedMotorcycleModels
import com.example.ui.components.StatusBadge
import com.example.ui.components.accentColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeadManagementScreen(
  leads: List<Lead>,
  onAddLead: (name: String, phone: String, model: String, status: LeadStatus) -> Unit,
  onUpdateLeadStatus: (leadId: Int, status: LeadStatus) -> Unit,
  onBack: () -> Unit,
) {
  BackHandler { onBack() }

  var showAddDialog by rememberSaveable { mutableStateOf(false) }

  Scaffold(
    containerColor = MaterialTheme.colorScheme.background,
    contentWindowInsets = WindowInsets.safeDrawing,
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = stringResource(R.string.leads_title),
              style = MaterialTheme.typography.titleLarge,
            )
            Text(
              text = stringResource(R.string.leads_count_label, leads.size),
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("leads_back_button")) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = stringResource(R.string.back_description),
            )
          }
        },
        actions = {
          Button(
            onClick = { showAddDialog = true },
            modifier = Modifier.padding(end = 12.dp).testTag("add_lead_button"),
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
              ),
          ) {
            Icon(
              imageVector = Icons.Filled.Add,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = stringResource(R.string.add_lead_button),
              style = MaterialTheme.typography.labelLarge,
            )
          }
        },
        colors =
          TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
          ),
      )
    },
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      if (leads.isEmpty()) {
        Column(
          modifier = Modifier.fillMaxWidth().widthIn(max = 600.dp).padding(32.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.PersonOutline,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(48.dp),
          )
          Text(
            text = stringResource(R.string.empty_leads_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text = stringResource(R.string.empty_leads_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxWidth().widthIn(max = 600.dp),
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          items(items = leads, key = { it.id }) { lead ->
            LeadCard(
              lead = lead,
              onStatusSelected = { newStatus -> onUpdateLeadStatus(lead.id, newStatus) },
            )
          }
        }
      }
    }
  }

  if (showAddDialog) {
    AddLeadDialog(
      onDismiss = { showAddDialog = false },
      onSave = { name, phone, model, status ->
        onAddLead(name, phone, model, status)
        showAddDialog = false
      },
    )
  }
}

@Composable
private fun LeadCard(
  lead: Lead,
  onStatusSelected: (LeadStatus) -> Unit,
) {
  var statusMenuExpanded by remember { mutableStateOf(false) }

  Card(
    modifier = Modifier.fillMaxWidth().testTag("lead_card_${lead.id}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = lead.customerName,
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
          modifier = Modifier.weight(1f).padding(end = 8.dp),
        )

        Box {
          StatusBadge(
            status = lead.status,
            showDropdownIcon = true,
            onClick = { statusMenuExpanded = true },
            modifier = Modifier.testTag("lead_status_button_${lead.id}"),
          )

          DropdownMenu(
            expanded = statusMenuExpanded,
            onDismissRequest = { statusMenuExpanded = false },
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
          ) {
            LeadStatus.entries.forEach { statusOption ->
              DropdownMenuItem(
                text = {
                  Text(
                    text = statusOption.label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = statusOption.accentColor(),
                  )
                },
                onClick = {
                  statusMenuExpanded = false
                  onStatusSelected(statusOption)
                },
                modifier = Modifier.testTag("status_option_${statusOption.name}"),
              )
            }
          }
        }
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.TwoWheeler,
          contentDescription = stringResource(R.string.motorcycle_model_label),
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(18.dp),
        )
        Text(
          text = lead.motorcycleModel,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Phone,
            contentDescription = stringResource(R.string.phone_number_label),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(16.dp),
          )
          Text(
            text = lead.phoneNumber,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        Text(
          text = stringResource(R.string.change_status_hint),
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddLeadDialog(
  onDismiss: () -> Unit,
  onSave: (name: String, phone: String, model: String, status: LeadStatus) -> Unit,
) {
  var customerName by rememberSaveable { mutableStateOf("") }
  var phoneNumber by rememberSaveable { mutableStateOf("") }
  var motorcycleModel by rememberSaveable { mutableStateOf("") }
  var selectedStatus by rememberSaveable { mutableStateOf(LeadStatus.NEW) }
  var showError by rememberSaveable { mutableStateOf(false) }

  val textFieldColors =
    OutlinedTextFieldDefaults.colors(
      focusedBorderColor = MaterialTheme.colorScheme.primary,
      unfocusedBorderColor = MaterialTheme.colorScheme.outline,
      focusedLabelColor = MaterialTheme.colorScheme.onBackground,
      unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
    )

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = MaterialTheme.colorScheme.surface,
    titleContentColor = MaterialTheme.colorScheme.onSurface,
    title = {
      Text(
        text = stringResource(R.string.add_lead_dialog_title),
        style = MaterialTheme.typography.titleLarge,
      )
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        OutlinedTextField(
          value = customerName,
          onValueChange = {
            customerName = it
            if (showError) showError = false
          },
          label = { Text(stringResource(R.string.customer_name_label)) },
          placeholder = { Text(stringResource(R.string.customer_name_placeholder)) },
          singleLine = true,
          keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
          colors = textFieldColors,
          modifier = Modifier.fillMaxWidth().testTag("lead_name_input"),
        )

        OutlinedTextField(
          value = phoneNumber,
          onValueChange = {
            phoneNumber = it
            if (showError) showError = false
          },
          label = { Text(stringResource(R.string.phone_number_label)) },
          placeholder = { Text(stringResource(R.string.phone_number_placeholder)) },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          colors = textFieldColors,
          modifier = Modifier.fillMaxWidth().testTag("lead_phone_input"),
        )

        OutlinedTextField(
          value = motorcycleModel,
          onValueChange = {
            motorcycleModel = it
            if (showError) showError = false
          },
          label = { Text(stringResource(R.string.motorcycle_model_label)) },
          placeholder = { Text(stringResource(R.string.motorcycle_model_placeholder)) },
          singleLine = true,
          keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
          colors = textFieldColors,
          modifier = Modifier.fillMaxWidth().testTag("lead_model_input"),
        )

        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          SuggestedMotorcycleModels.forEach { model ->
            SuggestionChip(
              onClick = {
                motorcycleModel = model
                if (showError) showError = false
              },
              label = { Text(model, style = MaterialTheme.typography.labelMedium) },
              colors =
                SuggestionChipDefaults.suggestionChipColors(
                  containerColor = MaterialTheme.colorScheme.surfaceVariant,
                  labelColor = MaterialTheme.colorScheme.onSurface,
                ),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            )
          }
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = stringResource(R.string.lead_status_label),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            LeadStatus.entries.forEach { status ->
              val selected = status == selectedStatus
              FilterChip(
                selected = selected,
                onClick = { selectedStatus = status },
                label = { Text(status.label) },
                colors =
                  FilterChipDefaults.filterChipColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                  ),
                modifier = Modifier.testTag("dialog_status_${status.name}"),
              )
            }
          }
        }

        if (showError) {
          Text(
            text = stringResource(R.string.form_error_required),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.error,
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (
            customerName.trim().isEmpty() ||
              phoneNumber.trim().isEmpty() ||
              motorcycleModel.trim().isEmpty()
          ) {
            showError = true
          } else {
            onSave(customerName, phoneNumber, motorcycleModel, selectedStatus)
          }
        },
        colors =
          ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
        modifier = Modifier.testTag("save_lead_button"),
      ) {
        Text(stringResource(R.string.save_lead_button))
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss, modifier = Modifier.testTag("cancel_lead_button")) {
        Text(
          text = stringResource(R.string.cancel_button),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    },
  )
}

package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.model.AppScreen
import com.example.model.Lead
import com.example.model.LeadStatus
import com.example.model.SalesTrackUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class SalesTrackViewModel : ViewModel() {

  private val _uiState = MutableStateFlow(SalesTrackUiState())
  val uiState: StateFlow<SalesTrackUiState> = _uiState.asStateFlow()

  private var nextLeadId = (_uiState.value.leads.maxOfOrNull { it.id } ?: 0) + 1

  fun continueToDashboard(executiveName: String) {
    val trimmed = executiveName.trim()
    if (trimmed.isEmpty()) return
    _uiState.update { it.copy(salesExecutiveName = trimmed, currentScreen = AppScreen.DASHBOARD) }
  }

  fun navigateTo(screen: AppScreen) {
    _uiState.update { it.copy(currentScreen = screen) }
  }

  fun addLead(
    customerName: String,
    phoneNumber: String,
    motorcycleModel: String,
    status: LeadStatus,
  ) {
    val cleanName = customerName.trim()
    val cleanPhone = phoneNumber.trim()
    val cleanModel = motorcycleModel.trim()
    if (cleanName.isEmpty() || cleanPhone.isEmpty() || cleanModel.isEmpty()) return

    val newLead =
      Lead(
        id = nextLeadId++,
        customerName = cleanName,
        phoneNumber = cleanPhone,
        motorcycleModel = cleanModel,
        status = status,
      )
    _uiState.update { state -> state.copy(leads = listOf(newLead) + state.leads) }
  }

  fun updateLeadStatus(leadId: Int, newStatus: LeadStatus) {
    _uiState.update { state ->
      state.copy(
        leads =
          state.leads.map { lead -> if (lead.id == leadId) lead.copy(status = newStatus) else lead }
      )
    }
  }
}

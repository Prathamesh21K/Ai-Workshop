package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Black, Charcoal, White, and Subtle Red palette
val ObsidianBlack = Color(0xFF0E0F12)
val CharcoalSurface = Color(0xFF17191E)
val CharcoalElevated = Color(0xFF21242B)
val CharcoalBorder = Color(0xFF2E323C)

val SubtleRed = Color(0xFFC62828)
val SubtleRedPressed = Color(0xFFB71C1C)
val SubtleRedContainer = Color(0xFF33181A)
val SubtleRedOnContainer = Color(0xFFFFDAD6)

val CrispWhite = Color(0xFFF5F5F7)
val MutedSteel = Color(0xFFA0A6B2)
val DimGray = Color(0xFF6B7280)

// Status pill accents (clean & readable on charcoal)
val StatusNewColor = Color(0xFF64B5F6)
val StatusContactedColor = Color(0xFFFFB74D)
val StatusTestRideColor = Color(0xFFE0E0E0)
val StatusBookedColor = Color(0xFFFFD54F)
val StatusSoldColor = Color(0xFF66BB6A)
val StatusLostColor = Color(0xFFEF5350)

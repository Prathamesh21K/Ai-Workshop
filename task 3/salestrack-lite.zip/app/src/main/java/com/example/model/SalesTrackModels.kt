package com.example.model

enum class AppScreen {
  WELCOME,
  DASHBOARD,
  LEADS,
  REPORTS,
}

enum class LeadStatus(val label: String) {
  NEW("New"),
  CONTACTED("Contacted"),
  TEST_RIDE("Test Ride"),
  BOOKED("Booked"),
  SOLD("Sold"),
  LOST("Lost"),
}

data class Lead(
  val id: Int,
  val customerName: String,
  val phoneNumber: String,
  val motorcycleModel: String,
  val status: LeadStatus,
)

data class SalesTrackUiState(
  val currentScreen: AppScreen = AppScreen.WELCOME,
  val salesExecutiveName: String = "",
  val leads: List<Lead> = SampleLeads,
) {
  val totalLeads: Int
    get() = leads.size

  val bookingsCount: Int
    get() = leads.count { it.status == LeadStatus.BOOKED }

  val completedSalesCount: Int
    get() = leads.count { it.status == LeadStatus.SOLD }

  val conversionPercentage: Float
    get() =
      if (leads.isEmpty()) 0f
      else (completedSalesCount.toFloat() / leads.size.toFloat()) * 100f

  val statusCounts: Map<LeadStatus, Int>
    get() = LeadStatus.entries.associateWith { status -> leads.count { it.status == status } }

  val recommendations: List<String>
    get() = buildRecommendations()

  private fun buildRecommendations(): List<String> {
    val list = mutableListOf<String>()
    val newCount = leads.count { it.status == LeadStatus.NEW }
    val contactedCount = leads.count { it.status == LeadStatus.CONTACTED }
    val testRideCount = leads.count { it.status == LeadStatus.TEST_RIDE }
    val bookedCount = bookingsCount
    val lostCount = leads.count { it.status == LeadStatus.LOST }

    if (newCount > 0) {
      list.add(
        "Follow up with $newCount new lead${if (newCount > 1) "s" else ""} today to schedule an initial showroom call."
      )
    } else if (contactedCount > 0) {
      list.add(
        "Invite your $contactedCount contacted prospect${if (contactedCount > 1) "s" else ""} for a weekend test ride."
      )
    } else {
      list.add("All new enquiries have been engaged. Focus on logging fresh walk-in enquiries.")
    }

    if (testRideCount > 0) {
      list.add(
        "$testRideCount customer${if (testRideCount > 1) "s have" else " has"} completed a test ride — share finance options to convert them to bookings."
      )
    } else if (bookedCount > 0) {
      list.add(
        "Prioritize delivery updates for $bookedCount booked customer${if (bookedCount > 1) "s" else ""} to finalize sales."
      )
    } else {
      list.add("Schedule more test rides to build momentum in the booking pipeline.")
    }

    if (leads.isNotEmpty() && conversionPercentage < 25f) {
      list.add(
        "Lead-to-sale conversion is under 25%. Review $lostCount lost lead${if (lostCount == 1) "" else "s"} and tighten post-test-ride follow-ups."
      )
    } else if (lostCount >= 2) {
      list.add(
        "Review the $lostCount lost leads to spot recurring price, stock, or delivery-time objections."
      )
    } else {
      list.add(
        "Conversion performance is healthy. Keep moving active bookings smoothly toward delivery."
      )
    }

    return list
  }
}

val SuggestedMotorcycleModels =
  listOf(
    "Classic 350",
    "Hunter 350",
    "Bullet 350",
    "Meteor 350",
    "Himalayan 450",
    "Interceptor 650",
    "Continental GT 650",
  )

val SampleLeads =
  listOf(
    Lead(
      id = 1,
      customerName = "Aarav Sharma",
      phoneNumber = "+91 98201 44120",
      motorcycleModel = "Classic 350",
      status = LeadStatus.SOLD,
    ),
    Lead(
      id = 2,
      customerName = "Priya Nair",
      phoneNumber = "+91 98452 77813",
      motorcycleModel = "Hunter 350",
      status = LeadStatus.BOOKED,
    ),
    Lead(
      id = 3,
      customerName = "Rohan Kulkarni",
      phoneNumber = "+91 97654 11290",
      motorcycleModel = "Himalayan 450",
      status = LeadStatus.TEST_RIDE,
    ),
    Lead(
      id = 4,
      customerName = "Vikram Mehta",
      phoneNumber = "+91 99103 55842",
      motorcycleModel = "Meteor 350",
      status = LeadStatus.CONTACTED,
    ),
    Lead(
      id = 5,
      customerName = "Ananya Verma",
      phoneNumber = "+91 98114 90321",
      motorcycleModel = "Interceptor 650",
      status = LeadStatus.NEW,
    ),
    Lead(
      id = 6,
      customerName = "Kabir Joshi",
      phoneNumber = "+91 97302 66418",
      motorcycleModel = "Bullet 350",
      status = LeadStatus.LOST,
    ),
  )

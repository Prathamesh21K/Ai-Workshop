package com.example

import com.example.model.AppScreen
import com.example.model.LeadStatus
import com.example.viewmodel.SalesTrackViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SalesTrackViewModelTest {

  @Test
  fun `continueToDashboard trims name and navigates to dashboard`() {
    val vm = SalesTrackViewModel()
    vm.continueToDashboard("  Arjun Deshmukh  ")
    val state = vm.uiState.value
    assertEquals(AppScreen.DASHBOARD, state.currentScreen)
    assertEquals("Arjun Deshmukh", state.salesExecutiveName)
  }

  @Test
  fun `addLead and updateLeadStatus update counts and conversion`() {
    val vm = SalesTrackViewModel()
    val initialCount = vm.uiState.value.totalLeads

    vm.addLead(
      customerName = "Siddharth Rao",
      phoneNumber = "+91 98765 43210",
      motorcycleModel = "Classic 350",
      status = LeadStatus.NEW,
    )

    assertEquals(initialCount + 1, vm.uiState.value.totalLeads)
    val addedLead = vm.uiState.value.leads.first()
    assertEquals("Siddharth Rao", addedLead.customerName)
    assertEquals(LeadStatus.NEW, addedLead.status)

    val initialSold = vm.uiState.value.completedSalesCount
    vm.updateLeadStatus(addedLead.id, LeadStatus.SOLD)

    assertEquals(initialSold + 1, vm.uiState.value.completedSalesCount)
    assertTrue(vm.uiState.value.recommendations.isNotEmpty())
  }
}
